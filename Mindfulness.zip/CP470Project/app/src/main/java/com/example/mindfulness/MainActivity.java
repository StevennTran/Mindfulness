package com.example.mindfulness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    ImageButton waterButton;
    int userID;
    final String LOGINID = "LOGINID";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i("onCreate", "MainActivity created");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        waterButton = findViewById(R.id.water_tracker);
        Bundle bundle = getIntent().getExtras().getBundle(LOGINID);
        userID = bundle.getInt("userID");
        Log.i("Main", Integer.toString(userID));
    }

    public void onClickWater(View view)
    {
        Log.i("onClick", "User clicked water tracker button");
        Intent intent = new Intent(MainActivity.this, WaterActivity.class);
        startActivity(intent);
    }

    public void onClickMood(View view)
    {
        Log.i("onClick", "User clicked mood tracker button");
        Intent intent = new Intent(MainActivity.this, MoodActivity.class);
        startActivity(intent);
    }

    public void onClickMeditate(View view)
    {
        Log.i("onClick", "User clicked meditate button");
        Intent intent = new Intent(MainActivity.this, MeditateActivity.class);
        startActivity(intent);
    }

    public void onClickSleep(View view)
    {
        Log.i("onClick", "User clicked sleep button");
        Intent intent = new Intent(MainActivity.this, SleepActivity.class);
        startActivity(intent);
    }

    public void onClickJournal(View view)
    {
        Log.i("onClick", "User clicked journal button");
        Intent intent = new Intent(MainActivity.this, JournalActivity.class);
        Bundle temp = new Bundle();
        temp.putInt("userID", userID);
        intent.putExtra(LOGINID, temp);
        startActivity(intent);
    }

    protected void onResume(){
        super.onResume();

    }

    protected void onStart(){
        super.onStart();

    }


    protected void onPause() {
        super.onPause();

    }

    protected void onStop(){
        super.onStop();

    }

    protected void onDestroy(){
        super.onDestroy();

    }
}